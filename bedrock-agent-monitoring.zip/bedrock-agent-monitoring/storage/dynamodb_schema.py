"""
Maps each collector source to a target DynamoDB table + the fields that make
up its sort key. This is the single place that encodes the "was PostgreSQL
table X" mapping from the README.
"""

SOURCE_TO_TABLE = {
    "cloudtrail": "access_usage",
    "xray": "performance_metrics",
    "cloudwatch_alarms": "failures",
    "cost_explorer": "cost_usage",
    "lookout_metrics": "failures",
    "feedback_api": "feedback",
    "guardrails": "guardrail_events",
    "bedrock_invocations": "model_invocations",
    "knowledge_base": "knowledge_base_events",
    "executions": "executions",
    "evaluation_api": "accuracy_evaluations",
    "agent_inventory": "agent_inventory",
}

# Tables keyed only by agent_id (no sort key) — loaded via put_item upsert,
# not the composite-sort-key batch path every other table uses.
SINGLE_KEY_TABLES = {"agent_inventory"}

# sort_key = "<timestamp>#<disambiguator_field>"
SORT_KEY_DISAMBIGUATOR = {
    "access_usage": "record_id",
    "performance_metrics": "source",       # xray vs future perf sources
    "failures": "record_id",
    "cost_usage": "service",
    "guardrail_events": "record_id",
    "model_invocations": "invocation_id",
    "knowledge_base_events": "session_id",
    "executions": "execution_id",
    "feedback": "feedback_id",
    "accuracy_evaluations": "evaluation_id",
}


def build_sort_key(table_key: str, record: dict) -> str:
    disambiguator_field = SORT_KEY_DISAMBIGUATOR.get(table_key, "record_id")
    disambiguator = record.get(disambiguator_field, record.get("record_id", "0"))
    return f"{record['timestamp']}#{disambiguator}"
