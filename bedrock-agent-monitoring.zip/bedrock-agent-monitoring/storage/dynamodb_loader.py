import logging
import boto3

from config.settings import TABLES, DEFAULT_TTL_SECONDS
from storage.dynamodb_schema import SOURCE_TO_TABLE, build_sort_key

logger = logging.getLogger(__name__)


class DynamoDBLoader:
    def __init__(self, region: str = "us-east-1"):
        self.resource = boto3.resource("dynamodb", region_name=region)
        self._table_cache = {}

    def _table(self, table_key: str):
        if table_key not in self._table_cache:
            self._table_cache[table_key] = self.resource.Table(TABLES[table_key])
        return self._table_cache[table_key]

    def load(self, source: str, records: list[dict]):
        table_key = SOURCE_TO_TABLE.get(source)
        if not table_key:
            logger.warning("no table mapping for source %s, skipping", source)
            return
        table = self._table(table_key)
        ttl_seconds = DEFAULT_TTL_SECONDS.get(table_key)

        with table.batch_writer(overwrite_by_pkeys=["agent_id", "sort_key"]) as batch:
            for record in records:
                item = dict(record)
                item["sort_key"] = build_sort_key(table_key, record)
                if ttl_seconds:
                    item["ttl"] = int(_now_epoch() + ttl_seconds)
                _add_gsi_string_keys(table_key, item)
                batch.put_item(Item=_clean_for_dynamo(item))


def _add_gsi_string_keys(table_key: str, item: dict) -> None:
    """DynamoDB GSI key attributes can't be type BOOL, so mirror any boolean
    flag used as a GSI hash key ('is_slow', 'no_answer') into a string field."""
    if table_key == "model_invocations" and "is_slow" in item:
        item["is_slow_str"] = "true" if item["is_slow"] else "false"
    if table_key == "knowledge_base_events" and "no_answer" in item:
        item["no_answer_str"] = "true" if item["no_answer"] else "false"


def _clean_for_dynamo(item: dict) -> dict:
    """DynamoDB rejects float type — cast to Decimal; drop None values."""
    from decimal import Decimal
    cleaned = {}
    for k, v in item.items():
        if v is None:
            continue
        if isinstance(v, float):
            cleaned[k] = Decimal(str(v))
        else:
            cleaned[k] = v
    return cleaned


def _now_epoch() -> int:
    from datetime import datetime, timezone
    return int(datetime.now(timezone.utc).timestamp())
