"""
Fetches secrets referenced by name from agents.yaml (custom_apis.*.secret_name).
This is ONLY for credentials that aren't AWS's own IAM auth — e.g. a bearer
token your Feedback API expects. AWS API calls (Bedrock, DynamoDB, CloudWatch,
Cost Explorer, X-Ray) never go through here: boto3 picks those up from the
IAM role automatically (see "AWS credentials" in the README) — putting AWS
keys in Secrets Manager and manually loading them is the wrong pattern.
"""
import json
import logging
from functools import lru_cache
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


@lru_cache(maxsize=32)
def get_secret(secret_name: str, region: str = "us-east-1") -> str | dict | None:
    if not secret_name:
        return None
    client = boto3.client("secretsmanager", region_name=region)
    try:
        resp = client.get_secret_value(SecretId=secret_name)
    except ClientError:
        logger.exception("could not fetch secret %s", secret_name)
        return None

    raw = resp.get("SecretString", "")
    try:
        return json.loads(raw)   # secrets stored as JSON (e.g. {"token": "..."})
    except json.JSONDecodeError:
        return raw               # plain-string secret
