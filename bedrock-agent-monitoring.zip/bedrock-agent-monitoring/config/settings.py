import os

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")

# DynamoDB table names (must match infrastructure/dynamodb_tables.yaml)
TABLES = {
    "agent_inventory": "AgentInventory",
    "performance_metrics": "PerformanceMetrics",
    "failures": "Failures",
    "access_usage": "AccessUsage",
    "cost_usage": "CostUsage",
    "aggregated_metrics": "AggregatedMetrics",
    "guardrail_events": "GuardrailEvents",
    "model_invocations": "ModelInvocations",       # extra: full per-call logs
    "knowledge_base_events": "KnowledgeBaseEvents",  # extra: RAG no-answer tracking
    "executions": "Executions",                      # matches your PostgreSQL schema
    "feedback": "Feedback",                          # matches your PostgreSQL schema
    "accuracy_evaluations": "AccuracyEvaluations",    # matches your PostgreSQL schema
}

# Which collectors run and how often (minutes). Toggle extras off if unused.
COLLECTOR_SCHEDULE = {
    "cloudtrail": 5,
    "xray": 5,
    "cloudwatch_alarms": 2,
    "lookout_metrics": 15,
    "cost_explorer": 60,
    "feedback_api": 10,
    "guardrails": 5,             # extra source
    "bedrock_invocations": 5,    # extra: every model call, not just guardrail hits
    "knowledge_base": 5,         # extra: RAG retrieval + no-answer detection
    "executions": 5,
    "evaluation_api": 15,
    "agent_inventory": 15,       # full-registry re-sync, not time-windowed
}

# A response slower than this (ms) is flagged is_slow=True on the record.
SLOW_RESPONSE_THRESHOLD_MS = 3000

# TTL for high-volume tables (seconds). Access/perf logs auto-expire; failures/cost don't.
DEFAULT_TTL_SECONDS = {
    "access_usage": 30 * 24 * 3600,      # 30 days
    "performance_metrics": 90 * 24 * 3600,  # 90 days
    "executions": 90 * 24 * 3600,
}
