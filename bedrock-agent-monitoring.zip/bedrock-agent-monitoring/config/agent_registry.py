"""
Loads config/agents.yaml once and exposes the agent list to every collector.
This is the layer that turns "one hardcoded agent" into "however many agents
are listed in the YAML" — every collector that needs to iterate agents pulls
from get_agents() instead of hardcoding an ID.
"""
from pathlib import Path
from functools import lru_cache
import yaml

REGISTRY_PATH = Path(__file__).parent / "agents.yaml"


@lru_cache(maxsize=1)
def _load() -> dict:
    with open(REGISTRY_PATH) as f:
        return yaml.safe_load(f)


def get_agents() -> list[dict]:
    """Every configured agent, e.g. for a collector that loops per-agent."""
    return _load().get("agents", [])


def get_agent(agent_id: str) -> dict | None:
    return next((a for a in get_agents() if a["agent_id"] == agent_id), None)


def get_custom_api_config(name: str) -> dict:
    """name: 'feedback_api' or 'evaluation_api'."""
    return _load().get("custom_apis", {}).get(name, {})


def reload() -> None:
    """Call after editing agents.yaml at runtime (e.g. in a long-lived process)."""
    _load.cache_clear()
