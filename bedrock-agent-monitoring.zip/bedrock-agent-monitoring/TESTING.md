# Testing locally

Three separate things worth testing, in increasing order of "how much real AWS you need":

## 1. Pure logic — no AWS, no Docker

```bash
pip install -r requirements-dev.txt --break-system-packages
python -m pytest tests/test_normalizer.py -v
```

Confirms the normalizer's field-mapping and slow-response logic is correct. Nothing here
touches a network.

## 2. "Is my collector actually pulling data from my agents?" — real AWS, no writes

This is what answers your original question directly. `scripts/dry_run_collector.py` runs
ONE collector against real AWS with your real credentials, prints whatever it finds, and
writes nothing to DynamoDB.

```bash
export AWS_REGION=us-east-1        # or export AWS_PROFILE=your-profile
python scripts/dry_run_collector.py cloudtrail --hours 24
python scripts/dry_run_collector.py xray --hours 24
python scripts/dry_run_collector.py bedrock_invocations --hours 24
python scripts/dry_run_collector.py knowledge_base --hours 24
python scripts/dry_run_collector.py agent_inventory
```

Run one at a time. Empty output means either nothing happened in that window, a prerequisite
isn't enabled (model invocation logging, trace logging, an anomaly detector), or the IAM
role/profile you're using doesn't have that source's read permission — the script prints
which of these is most likely.

For `feedback_api` / `evaluation_api`, set the URL env vars first:
```bash
export FEEDBACK_API_URL="https://your-feedback-api.example.com/items"
python scripts/dry_run_collector.py feedback_api
```

## 3. Full pipeline against DynamoDB Local — no real DynamoDB, optionally no real AWS at all

### 3a. Test the write path only (fastest — no AWS creds needed at all)

```bash
bash scripts/start_dynamodb_local.sh
export DYNAMODB_ENDPOINT_URL=http://localhost:8000
python scripts/create_local_tables.py
python scripts/seed_fake_data.py

# verify
aws dynamodb scan --table-name AgentInventory --endpoint-url http://localhost:8000
aws dynamodb scan --table-name ModelInvocations --endpoint-url http://localhost:8000

docker stop dynamodb-local     # when done
```

This proves the normalizer → loader → DynamoDB path (sort keys, GSI string mirrors, TTL,
single-key vs composite-key tables) is correct, entirely offline.

### 3b. Test the real pipeline end-to-end, writing to DynamoDB Local

Same as above, but point the real scheduler at DynamoDB Local instead of the seed script —
this hits real AWS for reads (CloudTrail, X-Ray, etc.) but writes to your local container
instead of production:

```bash
bash scripts/start_dynamodb_local.sh
export DYNAMODB_ENDPOINT_URL=http://localhost:8000
python scripts/create_local_tables.py
export AWS_REGION=us-east-1
python -m collectors.scheduler
```

## 4. Moto-mocked collector tests (optional, for CI)

`tests/test_cloudwatch_alarms_collector.py` is a template showing how to test a collector
against a *mocked* AWS API (via `moto`) instead of either real AWS or a manual dry run —
useful once you want this in CI without real credentials:

```bash
python -m pytest tests/test_cloudwatch_alarms_collector.py -v
```

Copy this pattern (seed fake data with the same boto3 client the collector uses, wrap the
test in `@mock_aws`) for any other collector you want covered.
