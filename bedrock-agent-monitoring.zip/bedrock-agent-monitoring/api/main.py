from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.routers import agents, performance, failures, invocations, knowledge_base, executions

app = FastAPI(title="Bedrock Agent Monitoring API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # tighten to your dashboard's origin in production
    allow_methods=["GET"],
)

app.include_router(agents.router, prefix="/api/agents", tags=["agents"])
app.include_router(performance.router, prefix="/api/performance", tags=["performance"])
app.include_router(failures.router, prefix="/api/failures", tags=["failures"])
app.include_router(invocations.router, prefix="/api/invocations", tags=["invocations"])
app.include_router(knowledge_base.router, prefix="/api/knowledge-base", tags=["knowledge-base"])
app.include_router(executions.router, prefix="/api/executions", tags=["executions"])


@app.get("/api/health")
def health():
    return {"status": "ok"}
