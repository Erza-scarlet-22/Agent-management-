from fastapi import APIRouter
from boto3.dynamodb.conditions import Key
from api.models import table, query_by_agent

router = APIRouter()


@router.get("/{agent_id}")
def get_invocations(agent_id: str, limit: int = 100):
    """Full per-call logs: model, tokens, latency, stop reason, guardrail action."""
    return query_by_agent("model_invocations", agent_id, limit=limit)


@router.get("/")
def get_slow_responses(limit: int = 100):
    """Every slow response (> SLOW_RESPONSE_THRESHOLD_MS) across all agents,
    via the SlowResponseIndex GSI — the base table's partition key is agent_id,
    so this can't be answered by querying one agent at a time."""
    resp = table("model_invocations").query(
        IndexName="SlowResponseIndex",
        KeyConditionExpression=Key("is_slow_str").eq("true"),
        Limit=limit,
        ScanIndexForward=False,
    )
    return resp.get("Items", [])
