from fastapi import APIRouter
from boto3.dynamodb.conditions import Key
from api.models import table, query_by_agent

router = APIRouter()


@router.get("/{agent_id}")
def get_executions(agent_id: str, limit: int = 100):
    return query_by_agent("executions", agent_id, limit=limit)


@router.get("/")
def get_failed_executions(limit: int = 100):
    """Cross-agent view via StatusIndex GSI."""
    resp = table("executions").query(
        IndexName="StatusIndex",
        KeyConditionExpression=Key("status").eq("FAILED"),
        Limit=limit,
        ScanIndexForward=False,
    )
    return resp.get("Items", [])
