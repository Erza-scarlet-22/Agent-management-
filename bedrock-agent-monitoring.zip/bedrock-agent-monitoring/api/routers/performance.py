from fastapi import APIRouter
from api.models import query_by_agent

router = APIRouter()


@router.get("/{agent_id}")
def get_performance(agent_id: str, limit: int = 100):
    return query_by_agent("performance_metrics", agent_id, limit=limit)
