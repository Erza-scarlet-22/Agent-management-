from fastapi import APIRouter, HTTPException
from api.models import table, scan_all

router = APIRouter()


@router.get("/")
def list_agents():
    return scan_all("agent_inventory", limit=500)


@router.get("/{agent_id}")
def get_agent(agent_id: str):
    resp = table("agent_inventory").get_item(Key={"agent_id": agent_id})
    item = resp.get("Item")
    if not item:
        raise HTTPException(status_code=404, detail="agent not found")
    return item
