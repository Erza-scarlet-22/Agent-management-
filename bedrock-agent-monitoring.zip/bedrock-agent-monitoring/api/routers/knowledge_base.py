from fastapi import APIRouter
from boto3.dynamodb.conditions import Key
from api.models import table, query_by_agent

router = APIRouter()


@router.get("/{agent_id}")
def get_kb_events(agent_id: str, limit: int = 100):
    """Every RAG retrieval event for this agent: query, citation count, no_answer flag."""
    return query_by_agent("knowledge_base_events", agent_id, limit=limit)


@router.get("/")
def get_no_answer_events(limit: int = 100):
    """Cross-agent view of every 'the agent couldn't actually answer' event —
    zero citations or an 'I don't know'-shaped response — via the NoAnswerIndex GSI."""
    resp = table("knowledge_base_events").query(
        IndexName="NoAnswerIndex",
        KeyConditionExpression=Key("no_answer_str").eq("true"),
        Limit=limit,
        ScanIndexForward=False,
    )
    return resp.get("Items", [])
