from fastapi import APIRouter
from boto3.dynamodb.conditions import Key
from api.models import table, query_by_agent

router = APIRouter()


@router.get("/{agent_id}")
def get_agent_failures(agent_id: str, limit: int = 100):
    return query_by_agent("failures", agent_id, limit=limit)


@router.get("/")
def get_critical_failures(severity: str = "CRITICAL", limit: int = 100):
    """Cross-agent view — uses the SeverityIndex GSI since 'all critical failures
    across every agent' can't be answered from the base table's agent_id partition key."""
    resp = table("failures").query(
        IndexName="SeverityIndex",
        KeyConditionExpression=Key("severity").eq(severity),
        Limit=limit,
        ScanIndexForward=False,
    )
    return resp.get("Items", [])
