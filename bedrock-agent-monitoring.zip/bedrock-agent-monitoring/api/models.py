import boto3
from boto3.dynamodb.conditions import Key

from config.settings import TABLES, AWS_REGION, DYNAMODB_ENDPOINT_URL

_resource = boto3.resource("dynamodb", region_name=AWS_REGION, endpoint_url=DYNAMODB_ENDPOINT_URL)


def table(table_key: str):
    return _resource.Table(TABLES[table_key])


def query_by_agent(table_key: str, agent_id: str, limit: int = 100, scan_forward: bool = False):
    resp = table(table_key).query(
        KeyConditionExpression=Key("agent_id").eq(agent_id),
        Limit=limit,
        ScanIndexForward=scan_forward,   # False = most recent first
    )
    return resp.get("Items", [])


def scan_all(table_key: str, limit: int = 200):
    resp = table(table_key).scan(Limit=limit)
    return resp.get("Items", [])
