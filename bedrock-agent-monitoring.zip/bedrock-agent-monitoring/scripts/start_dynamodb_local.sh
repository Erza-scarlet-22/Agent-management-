#!/usr/bin/env bash
# Starts DynamoDB Local in Docker on port 8000. No AWS account, no cost.
set -e
docker run -d --rm \
  --name dynamodb-local \
  -p 8000:8000 \
  amazon/dynamodb-local \
  -jar DynamoDBLocal.jar -sharedDb -inMemory

echo "DynamoDB Local running at http://localhost:8000"
echo "Stop it with: docker stop dynamodb-local"
