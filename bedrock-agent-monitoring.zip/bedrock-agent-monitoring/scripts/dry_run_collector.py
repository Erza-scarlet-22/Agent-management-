"""
Run ONE collector against real AWS and print what it finds — no DynamoDB
write happens. This is the fastest way to answer "is my collector actually
pulling data from my agents" without touching any table.

Usage:
    python scripts/dry_run_collector.py cloudtrail
    python scripts/dry_run_collector.py xray --hours 6
    python scripts/dry_run_collector.py agent_inventory
"""
import argparse
import json
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, ".")  # run from the project root

from collectors.scheduler import COLLECTORS
from config.settings import AWS_REGION
from transformer.normalizer import normalize


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", choices=list(COLLECTORS.keys()))
    parser.add_argument("--hours", type=float, default=1, help="lookback window")
    parser.add_argument("--raw", action="store_true", help="skip normalization, show raw output")
    args = parser.parse_args()

    since = datetime.now(timezone.utc) - timedelta(hours=args.hours)
    collector_cls = COLLECTORS[args.source]
    collector = collector_cls(region=AWS_REGION)

    print(f"--- running '{args.source}' collector, since {since.isoformat()} ---")
    records = collector.run(since)
    print(f"--- {len(records)} raw record(s) ---")

    if not args.raw:
        records = [r for r in (normalize(r) for r in records) if r is not None]
        print(f"--- {len(records)} record(s) after normalization ---")

    for r in records[:20]:
        print(json.dumps(r, indent=2, default=str))
    if len(records) > 20:
        print(f"... and {len(records) - 20} more (truncated)")

    if not records:
        print(
            "\nNo records found. Common causes:\n"
            "  - lookback window (--hours) doesn't cover any real activity\n"
            "  - the source-specific prerequisite isn't enabled yet "
            "(model invocation logging, agent trace logging, an anomaly detector, etc.)\n"
            "  - IAM role/credentials don't have permission for this source's API calls\n"
            "  - for feedback_api / evaluation_api: the *_API_URL env var isn't set"
        )


if __name__ == "__main__":
    main()
