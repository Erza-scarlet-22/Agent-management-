"""
Creates every table + GSI from infrastructure/dynamodb_tables.yaml against
DynamoDB Local (a Docker container that emulates DynamoDB with no AWS account
needed). Table/GSI definitions are kept here in plain boto3 form rather than
parsed from the CloudFormation YAML, since DynamoDB Local has no CloudFormation
support of its own.

Usage: run scripts/start_dynamodb_local.sh first, then:
    python scripts/create_local_tables.py
"""
import boto3

ENDPOINT = "http://localhost:8000"

client = boto3.client(
    "dynamodb",
    endpoint_url=ENDPOINT,
    region_name="us-east-1",
    aws_access_key_id="local",     # DynamoDB Local ignores these but boto3 requires *something*
    aws_secret_access_key="local",
)


def _gsi(name: str, hash_key: str, range_key: str) -> dict:
    return {
        "IndexName": name,
        "KeySchema": [
            {"AttributeName": hash_key, "KeyType": "HASH"},
            {"AttributeName": range_key, "KeyType": "RANGE"},
        ],
        "Projection": {"ProjectionType": "ALL"},
    }


TABLES = [
    {
        "TableName": "AgentInventory",
        "KeySchema": [{"AttributeName": "agent_id", "KeyType": "HASH"}],
        "AttributeDefinitions": [{"AttributeName": "agent_id", "AttributeType": "S"}],
    },
    {
        "TableName": "PerformanceMetrics",
        "KeySchema": [
            {"AttributeName": "agent_id", "KeyType": "HASH"},
            {"AttributeName": "sort_key", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_id", "AttributeType": "S"},
            {"AttributeName": "sort_key", "AttributeType": "S"},
            {"AttributeName": "metric_type", "AttributeType": "S"},
            {"AttributeName": "timestamp", "AttributeType": "S"},
        ],
        "GlobalSecondaryIndexes": [_gsi("MetricTypeIndex", "metric_type", "timestamp")],
    },
    {
        "TableName": "Failures",
        "KeySchema": [
            {"AttributeName": "agent_id", "KeyType": "HASH"},
            {"AttributeName": "sort_key", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_id", "AttributeType": "S"},
            {"AttributeName": "sort_key", "AttributeType": "S"},
            {"AttributeName": "severity", "AttributeType": "S"},
            {"AttributeName": "timestamp", "AttributeType": "S"},
        ],
        "GlobalSecondaryIndexes": [_gsi("SeverityIndex", "severity", "timestamp")],
    },
    {
        "TableName": "AccessUsage",
        "KeySchema": [
            {"AttributeName": "agent_id", "KeyType": "HASH"},
            {"AttributeName": "sort_key", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_id", "AttributeType": "S"},
            {"AttributeName": "sort_key", "AttributeType": "S"},
        ],
    },
    {
        "TableName": "CostUsage",
        "KeySchema": [
            {"AttributeName": "agent_id", "KeyType": "HASH"},
            {"AttributeName": "sort_key", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_id", "AttributeType": "S"},
            {"AttributeName": "sort_key", "AttributeType": "S"},
        ],
    },
    {
        "TableName": "AggregatedMetrics",
        "KeySchema": [
            {"AttributeName": "agent_period", "KeyType": "HASH"},
            {"AttributeName": "metric_name", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_period", "AttributeType": "S"},
            {"AttributeName": "metric_name", "AttributeType": "S"},
        ],
    },
    {
        "TableName": "GuardrailEvents",
        "KeySchema": [
            {"AttributeName": "agent_id", "KeyType": "HASH"},
            {"AttributeName": "sort_key", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_id", "AttributeType": "S"},
            {"AttributeName": "sort_key", "AttributeType": "S"},
        ],
    },
    {
        "TableName": "ModelInvocations",
        "KeySchema": [
            {"AttributeName": "agent_id", "KeyType": "HASH"},
            {"AttributeName": "sort_key", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_id", "AttributeType": "S"},
            {"AttributeName": "sort_key", "AttributeType": "S"},
            {"AttributeName": "is_slow_str", "AttributeType": "S"},
            {"AttributeName": "timestamp", "AttributeType": "S"},
        ],
        "GlobalSecondaryIndexes": [_gsi("SlowResponseIndex", "is_slow_str", "timestamp")],
    },
    {
        "TableName": "KnowledgeBaseEvents",
        "KeySchema": [
            {"AttributeName": "agent_id", "KeyType": "HASH"},
            {"AttributeName": "sort_key", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_id", "AttributeType": "S"},
            {"AttributeName": "sort_key", "AttributeType": "S"},
            {"AttributeName": "no_answer_str", "AttributeType": "S"},
            {"AttributeName": "timestamp", "AttributeType": "S"},
        ],
        "GlobalSecondaryIndexes": [_gsi("NoAnswerIndex", "no_answer_str", "timestamp")],
    },
    {
        "TableName": "Executions",
        "KeySchema": [
            {"AttributeName": "agent_id", "KeyType": "HASH"},
            {"AttributeName": "sort_key", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_id", "AttributeType": "S"},
            {"AttributeName": "sort_key", "AttributeType": "S"},
            {"AttributeName": "status", "AttributeType": "S"},
            {"AttributeName": "timestamp", "AttributeType": "S"},
        ],
        "GlobalSecondaryIndexes": [_gsi("StatusIndex", "status", "timestamp")],
    },
    {
        "TableName": "Feedback",
        "KeySchema": [
            {"AttributeName": "agent_id", "KeyType": "HASH"},
            {"AttributeName": "sort_key", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_id", "AttributeType": "S"},
            {"AttributeName": "sort_key", "AttributeType": "S"},
        ],
    },
    {
        "TableName": "AccuracyEvaluations",
        "KeySchema": [
            {"AttributeName": "agent_id", "KeyType": "HASH"},
            {"AttributeName": "sort_key", "KeyType": "RANGE"},
        ],
        "AttributeDefinitions": [
            {"AttributeName": "agent_id", "AttributeType": "S"},
            {"AttributeName": "sort_key", "AttributeType": "S"},
        ],
    },
]


def main():
    existing = set(client.list_tables()["TableNames"])
    for table_def in TABLES:
        name = table_def["TableName"]
        if name in existing:
            print(f"skip (exists): {name}")
            continue
        kwargs = dict(table_def)
        kwargs["BillingMode"] = "PAY_PER_REQUEST"
        client.create_table(**kwargs)
        print(f"created: {name}")


if __name__ == "__main__":
    main()
