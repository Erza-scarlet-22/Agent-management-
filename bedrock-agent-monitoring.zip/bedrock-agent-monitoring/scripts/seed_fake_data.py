"""
Pushes fake-but-realistic records through the REAL normalizer + DynamoDB
loader code, into DynamoDB Local. This tests "does my pipeline correctly
write to DynamoDB" in total isolation from AWS credentials/permissions —
useful before you've even set up IAM, CloudTrail access, etc.

Usage:
    export DYNAMODB_ENDPOINT_URL=http://localhost:8000
    python scripts/seed_fake_data.py
"""
import sys
from datetime import datetime, timezone

sys.path.insert(0, ".")

from transformer.normalizer import normalize
from storage.dynamodb_loader import DynamoDBLoader

NOW = datetime.now(timezone.utc).isoformat()

FAKE_RECORDS = {
    "cloudtrail": [
        {"source": "cloudtrail", "agent_id": "AGENT123ABC", "event_name": "InvokeAgent",
         "event_time": NOW, "username": "test-user", "event_id": "evt-1"},
    ],
    "xray": [
        {"source": "xray", "agent_id": "AGENT123ABC", "trace_id": "trace-1",
         "duration_ms": 4200, "response_time_ms": 4100, "has_error": False,
         "has_fault": False, "has_throttle": False, "timestamp": NOW},
    ],
    "cloudwatch_alarms": [
        {"source": "cloudwatch_alarms", "agent_id": "AGENT123ABC", "alarm_name": "bedrock-agent-AGENT123ABC-errors",
         "state": "ALARM", "reason": "Threshold crossed", "metric_name": "Errors", "timestamp": NOW},
    ],
    "bedrock_invocations": [
        {"source": "bedrock_invocations", "agent_id": "AGENT123ABC", "model_id": "anthropic.claude-sonnet-4-5",
         "invocation_id": "inv-1", "input_tokens": 500, "output_tokens": 200, "total_tokens": 700,
         "latency_ms": 4200, "stop_reason": "end_turn", "guardrail_action": "NONE", "timestamp": NOW},
    ],
    "knowledge_base": [
        {"source": "knowledge_base", "agent_id": "AGENT123ABC", "session_id": "sess-1",
         "kb_id": "KB789GHI", "query": "what is our refund policy?", "citation_count": 0,
         "top_score": 0, "no_answer": True, "response_excerpt": "I don't have enough information.",
         "timestamp": NOW},
    ],
    "executions": [
        {"source": "executions", "agent_id": "AGENT123ABC", "execution_id": "exec-1",
         "session_id": "sess-1", "correlation_id": "corr-1", "start_time": NOW,
         "end_time": NOW, "duration_ms": 4200, "status": "SUCCESS", "timestamp": NOW},
    ],
    "feedback_api": [
        {"source": "feedback_api", "agent_id": "AGENT123ABC", "execution_id": "exec-1",
         "feedback_id": "fb-1", "rating": 5, "is_thumbs_up": True, "comments": "great answer",
         "timestamp": NOW},
    ],
    "agent_inventory": [
        {"source": "agent_inventory", "agent_id": "AGENT123ABC", "agent_name": "customer-support-agent",
         "agent_alias_id": "ALIAS456DEF", "foundation_model": "anthropic.claude-sonnet-4-5",
         "environment": "prod", "knowledge_base_id": "KB789GHI", "status": "PREPARED",
         "updated_at": NOW},
    ],
}


def main():
    loader = DynamoDBLoader(region="us-east-1")
    for source, raw_records in FAKE_RECORDS.items():
        clean = [r for r in (normalize(r) for r in raw_records) if r is not None]
        loader.load(source, clean)
        print(f"seeded {len(clean)} record(s) for '{source}'")

    print("\nDone. Verify with the AWS CLI against the local endpoint, e.g.:")
    print("  aws dynamodb scan --table-name AgentInventory --endpoint-url http://localhost:8000")


if __name__ == "__main__":
    main()
