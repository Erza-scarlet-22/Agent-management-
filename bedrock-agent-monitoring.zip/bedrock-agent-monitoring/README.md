# Bedrock Agent Monitoring — Dashboard Tab

Replicates the "Bedrock Agent Monitoring Development Plan" architecture, with
**DynamoDB** in place of PostgreSQL, wired up as a new tab in your existing
Flask log-aggregation dashboard.

## Architecture

```
AWS Data Sources → Python Collectors → Transformer/Normalizer → DynamoDB → REST API (FastAPI) → Dashboard tab
```

### AWS Data Sources
From your diagram:
- Bedrock Agent APIs (invocations, traces)
- CloudTrail logs
- Lookout for Metrics (anomalies)
- X-Ray / OpenTelemetry (traces)
- CloudWatch Alarms
- AWS Cost Explorer
- Custom APIs (Feedback API, Evaluation API)

Added (not in original diagram, optional — toggle in `config/settings.py`):
- **Bedrock Guardrails** intervention logs (blocked/flagged content only)
- **Bedrock Model Invocation Logging** (`bedrock_invocation_collector.py`) — *every* model
  call, not just guardrail hits: tokens in/out, latency, model ID, stop reason. Also the
  source of `is_slow` flagging (see below) and a same-day cost proxy, since Cost Explorer
  lags ~24h.
- **Knowledge Base retrieval tracking** (`knowledge_base_collector.py`) — reads agent trace
  logs, extracts each `knowledgeBaseLookupOutput` step, and flags a query as a **no-answer
  event** when either retrieval returned zero references or the final response matches an
  "I don't have enough information" pattern. This is the gap PostgreSQL/`Failures` never
  covered: the agent responding without actually answering isn't an exception, so it never
  hit an alarm or a stack trace.
- **Slow-response flagging** — any record from *any* source with a `duration_ms` /
  `response_time_ms` / `latency_ms` field gets `is_slow` set centrally in
  `transformer/normalizer.py` against `SLOW_RESPONSE_THRESHOLD_MS` (default 3000ms), so
  "how many slow responses today" is one query regardless of which collector saw it.

### Python Data Pipeline
- `scheduler.py` — EventBridge-triggered (or cron) orchestrator, runs each collector on its
  own interval
- `collectors/*.py` — one module per source, each returns normalized raw records
- `transformer/normalizer.py` — schema validation + UTC normalization
- `storage/dynamodb_loader.py` — idempotent batch writer (upsert on composite key)

### DynamoDB (replaces PostgreSQL 16+/RDS)
Multi-table design, mapped 1:1 to your original Postgres tables so the migration is easy to
reason about. See `infrastructure/dynamodb_tables.yaml` for full schema + GSIs.

| Table | PK | SK | Purpose |
|---|---|---|---|
| `AgentInventory` | `agent_id` | `metadata` | agent registry (was `agent_inventory`) |
| `PerformanceMetrics` | `agent_id` | `timestamp#metric_type` | latency/traces (was `performance_metrics`) |
| `Failures` | `agent_id` | `timestamp#failure_id` | errors/faults (was `failures`) |
| `AccessUsage` | `agent_id` | `timestamp#user_id` | invocation/usage logs (was `access_usage`) |
| `CostUsage` | `agent_id` | `date#service` | cost breakdown (was `cost_usage`) |
| `AggregatedMetrics` | `agent_id#period` | `metric_name` | rollups (was `aggregated_metrics`) |
| `GuardrailEvents` | `agent_id` | `timestamp#event_id` | *new* — blocks/redactions |
| `ModelInvocations` | `agent_id` | `timestamp#invocation_id` | *new* — every call, full detail |
| `KnowledgeBaseEvents` | `agent_id` | `timestamp#session_id` | *new* — RAG retrieval + no-answer flag |

Cross-agent GSIs: `SeverityIndex` (Failures), `SlowResponseIndex` (ModelInvocations),
`NoAnswerIndex` (KnowledgeBaseEvents) — each lets you ask "show me every X across all
agents" without a full table scan.

GSIs added for the query patterns your REST API needs (e.g. "all failures across agents in
last 24h" — DynamoDB can't do cross-partition scans efficiently without one).

### REST API (FastAPI) — unchanged shape, new backend
Same endpoint surface as your diagram, now reading from DynamoDB via `boto3`.

### Dashboard tab
`dashboard/templates/bedrock_monitoring_tab.html` — drop-in Jinja partial + JS panel that
polls the new API and renders into your existing Flask dashboard shell (Overview / Agents /
Performance / Alerts / Cost / Feedback, matching your diagram's rightmost column).

## Folder structure

```
bedrock-agent-monitoring/
├── collectors/
│   ├── __init__.py
│   ├── base_collector.py
│   ├── scheduler.py
│   ├── cloudtrail_collector.py
│   ├── xray_collector.py
│   ├── cloudwatch_alarms_collector.py
│   ├── cost_explorer_collector.py
│   ├── lookout_metrics_collector.py
│   ├── feedback_api_collector.py
│   ├── guardrails_collector.py         # extra source
│   ├── bedrock_invocation_collector.py # extra: full per-call logs
│   └── knowledge_base_collector.py     # extra: RAG no-answer detection
├── transformer/
│   ├── __init__.py
│   └── normalizer.py                   # includes cross-source is_slow flagging
├── storage/
│   ├── __init__.py
│   ├── dynamodb_schema.py
│   └── dynamodb_loader.py
├── api/
│   ├── __init__.py
│   ├── main.py
│   └── routers/
│       ├── agents.py
│       ├── performance.py
│       ├── failures.py
│       ├── invocations.py              # per-call logs + slow-response GSI query
│       └── knowledge_base.py           # KB events + no-answer GSI query
├── dashboard/
│   └── templates/
│       └── bedrock_monitoring_tab.html
├── infrastructure/
│   └── dynamodb_tables.yaml            # CloudFormation
├── config/
│   └── settings.py
├── requirements.txt
└── README.md
```

## Prerequisites for the new collectors

- **Model invocation logging**: Bedrock console → Settings → Model invocation logging →
  enable, destination CloudWatch Logs, log group `/aws/bedrock/modelinvocations` (or update
  the path in `bedrock_invocation_collector.py`).
- **Agent trace logging**: on each agent alias, enable "Trace" and point it at a CloudWatch
  Logs group, e.g. `/aws/bedrock/agenttraces` (or update the path in
  `knowledge_base_collector.py`). Without this, `knowledge_base_events` stays empty.

## Setup

```bash
cd bedrock-agent-monitoring
pip install -r requirements.txt
aws cloudformation deploy \
  --template-file infrastructure/dynamodb_tables.yaml \
  --stack-name bedrock-monitoring-dynamodb \
  --capabilities CAPABILITY_IAM

python -m collectors.scheduler          # run pipeline once / on schedule
uvicorn api.main:app --reload --port 8001   # REST API
```

Then mount the Flask blueprint / include the Jinja partial in your existing dashboard app
(see comment at the top of `bedrock_monitoring_tab.html`).
