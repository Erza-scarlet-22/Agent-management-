# Bedrock Agent Monitoring — Dashboard Tab

Replicates the "Bedrock Agent Monitoring Development Plan" architecture, with
**DynamoDB** in place of PostgreSQL, wired up as a new tab in your existing
Flask log-aggregation dashboard.

## Architecture

```
AWS Data Sources → Python Collectors → Transformer/Normalizer → DynamoDB → REST API (FastAPI) → Dashboard tab
```

### AWS Data Sources
From your diagram:
- Bedrock Agent APIs (invocations, traces)
- CloudTrail logs
- Lookout for Metrics (anomalies)
- X-Ray / OpenTelemetry (traces)
- CloudWatch Alarms
- AWS Cost Explorer
- Custom APIs (Feedback API, Evaluation API)

Added (not in original diagram, optional — toggle in `config/settings.py`):
- **Bedrock Guardrails** intervention logs (blocked/flagged content only)
- **Bedrock Model Invocation Logging** (`bedrock_invocation_collector.py`) — *every* model
  call, not just guardrail hits: tokens in/out, latency, model ID, stop reason. Also the
  source of `is_slow` flagging (see below) and a same-day cost proxy, since Cost Explorer
  lags ~24h.
- **Knowledge Base retrieval tracking** (`knowledge_base_collector.py`) — reads agent trace
  logs, extracts each `knowledgeBaseLookupOutput` step, and flags a query as a **no-answer
  event** when either retrieval returned zero references or the final response matches an
  "I don't have enough information" pattern. This is the gap PostgreSQL/`Failures` never
  covered: the agent responding without actually answering isn't an exception, so it never
  hit an alarm or a stack trace.
- **Slow-response flagging** — any record from *any* source with a `duration_ms` /
  `response_time_ms` / `latency_ms` field gets `is_slow` set centrally in
  `transformer/normalizer.py` against `SLOW_RESPONSE_THRESHOLD_MS` (default 3000ms), so
  "how many slow responses today" is one query regardless of which collector saw it.

### Python Data Pipeline
- `scheduler.py` — EventBridge-triggered (or cron) orchestrator, runs each collector on its
  own interval
- `collectors/*.py` — one module per source, each returns normalized raw records
- `transformer/normalizer.py` — schema validation + UTC normalization
- `storage/dynamodb_loader.py` — idempotent batch writer (upsert on composite key)

### DynamoDB (replaces PostgreSQL 16+/RDS)
Multi-table design, mapped 1:1 to your original Postgres tables so the migration is easy to
reason about. See `infrastructure/dynamodb_tables.yaml` for full schema + GSIs.

| Table | PK | SK | Purpose |
|---|---|---|---|
| `AgentInventory` | `agent_id` | `metadata` | agent registry (was `agent_inventory`) |
| `PerformanceMetrics` | `agent_id` | `timestamp#metric_type` | latency/traces (was `performance_metrics`) |
| `Failures` | `agent_id` | `timestamp#failure_id` | errors/faults (was `failures`) |
| `AccessUsage` | `agent_id` | `timestamp#user_id` | invocation/usage logs (was `access_usage`) |
| `CostUsage` | `agent_id` | `date#service` | cost breakdown (was `cost_usage`) |
| `AggregatedMetrics` | `agent_id#period` | `metric_name` | rollups (was `aggregated_metrics`) |
| `GuardrailEvents` | `agent_id` | `timestamp#event_id` | *new* — blocks/redactions |
| `ModelInvocations` | `agent_id` | `timestamp#invocation_id` | *new* — every call, full detail |
| `KnowledgeBaseEvents` | `agent_id` | `timestamp#session_id` | *new* — RAG retrieval + no-answer flag |
| `Executions` | `agent_id` | `timestamp#execution_id` | top-level run tracking (session/correlation/status) |
| `Feedback` | `agent_id` | `timestamp#feedback_id` | rating + `is_thumbs_up`, separated from access_usage |
| `AccuracyEvaluations` | `agent_id` | `timestamp#evaluation_id` | accuracy/relevance/completeness scores |

Cross-agent GSIs: `SeverityIndex` (Failures), `SlowResponseIndex` (ModelInvocations),
`NoAnswerIndex` (KnowledgeBaseEvents), `StatusIndex` (Executions) — each lets you ask "show
me every X across all agents" without a full table scan.
`AgentInventory` has no sort key — it's a plain per-agent upsert, synced from
`config/agents.yaml` on every `agent_inventory` collector run.

GSIs added for the query patterns your REST API needs (e.g. "all failures across agents in
last 24h" — DynamoDB can't do cross-partition scans efficiently without one).

### REST API (FastAPI) — unchanged shape, new backend
Same endpoint surface as your diagram, now reading from DynamoDB via `boto3`.

### Dashboard tab
`dashboard/templates/bedrock_monitoring_tab.html` — drop-in Jinja partial + JS panel that
polls the new API and renders into your existing Flask dashboard shell (Overview / Agents /
Performance / Alerts / Cost / Feedback, matching your diagram's rightmost column).

## Folder structure

```
bedrock-agent-monitoring/
├── collectors/
│   ├── __init__.py
│   ├── base_collector.py
│   ├── scheduler.py
│   ├── cloudtrail_collector.py
│   ├── xray_collector.py
│   ├── cloudwatch_alarms_collector.py
│   ├── cost_explorer_collector.py
│   ├── lookout_metrics_collector.py
│   ├── feedback_api_collector.py
│   ├── guardrails_collector.py           # extra source
│   ├── bedrock_invocation_collector.py   # extra: full per-call logs
│   ├── knowledge_base_collector.py       # extra: RAG no-answer detection
│   ├── executions_collector.py           # matches PostgreSQL 'executions'
│   ├── evaluation_api_collector.py       # matches PostgreSQL 'accuracy_evaluations'
│   └── agent_inventory_collector.py      # syncs config/agents.yaml -> DynamoDB
├── transformer/
│   ├── __init__.py
│   └── normalizer.py                     # includes cross-source is_slow flagging
├── storage/
│   ├── __init__.py
│   ├── dynamodb_schema.py
│   ├── dynamodb_loader.py
│   └── secrets_manager.py                # fetches non-AWS secrets (Secrets Manager)
├── api/
│   ├── __init__.py
│   ├── main.py
│   ├── models.py
│   └── routers/
│       ├── agents.py
│       ├── performance.py
│       ├── failures.py
│       ├── invocations.py                # per-call logs + slow-response GSI query
│       ├── knowledge_base.py             # KB events + no-answer GSI query
│       └── executions.py                 # runs + failed-execution GSI query
├── dashboard/
│   └── templates/
│       └── bedrock_monitoring_tab.html
├── infrastructure/
│   ├── dynamodb_tables.yaml              # CloudFormation
│   └── iam_role.yaml                     # least-privilege execution role
├── config/
│   ├── settings.py
│   ├── agents.yaml                       # <- your agent details go here
│   └── agent_registry.py                 # loads agents.yaml
├── requirements.txt
└── README.md
```

## Prerequisites for the new collectors

- **Model invocation logging**: Bedrock console → Settings → Model invocation logging →
  enable, destination CloudWatch Logs, log group `/aws/bedrock/modelinvocations` (or update
  the path in `bedrock_invocation_collector.py`).
- **Agent trace logging**: on each agent alias, enable "Trace" and point it at a CloudWatch
  Logs group, e.g. `/aws/bedrock/agenttraces` (or update the path in
  `knowledge_base_collector.py`). Without this, `knowledge_base_events` stays empty.

## Connecting your Bedrock agents (multiple agents + AWS secrets)

**Agent details go in `config/agents.yaml`** — one block per agent (`agent_id`,
`agent_alias_id`, `foundation_model`, `environment`, `knowledge_base_id`). Every collector
that needs to loop over agents calls `config.agent_registry.get_agents()`, so adding a new
agent is a YAML edit, not a code change. `collectors/agent_inventory_collector.py` reads
this file every run and syncs it (plus live status from Bedrock's `get_agent` API) into the
`AgentInventory` DynamoDB table — that's what backs the dashboard's Agents tab.

**AWS credentials — do NOT put AWS access keys anywhere in this repo.** Every `boto3`
client here (`bedrock-agent`, `dynamodb`, `cloudtrail`, `xray`, `logs`, `ce`, ...)
authenticates via the IAM role attached to wherever the code runs — `infrastructure/iam_role.yaml`
defines exactly that role, scoped to only the actions/tables this pipeline needs. Locally,
`aws configure` / `AWS_PROFILE` gives boto3 the same thing for testing. There is
intentionally no `aws_access_key_id` anywhere in this codebase.

**Non-AWS secrets** (e.g. a bearer token your own Feedback/Evaluation API expects) go in
**AWS Secrets Manager**, referenced by name from `agents.yaml`'s `custom_apis` block and
fetched at runtime by `storage/secrets_manager.py`:

```bash
aws secretsmanager create-secret \
  --name bedrock-monitoring/feedback-api-token \
  --secret-string '{"token":"<your-token>"}'
```

## Connecting to DynamoDB

Nothing to "connect" with a connection string — `storage/dynamodb_loader.py` and
`api/models.py` both call `boto3.resource("dynamodb", region_name=...)`, which uses the same
IAM-role credentials as everything else. The only things you set are:
- `AWS_REGION` env var (defaults to `us-east-1` in `config/settings.py`)
- Table names in `config/settings.py` → `TABLES`, if you rename anything in the CloudFormation

## Setup / execution steps

```bash
cd bedrock-agent-monitoring
pip install -r requirements.txt

# 1. IAM role (boto3's actual credentials source — do this before anything else)
aws cloudformation deploy \
  --template-file infrastructure/iam_role.yaml \
  --stack-name bedrock-monitoring-iam \
  --capabilities CAPABILITY_NAMED_IAM

# 2. DynamoDB tables
aws cloudformation deploy \
  --template-file infrastructure/dynamodb_tables.yaml \
  --stack-name bedrock-monitoring-dynamodb \
  --capabilities CAPABILITY_IAM

# 3. Secrets (only if you use the Feedback/Evaluation custom APIs)
aws secretsmanager create-secret --name bedrock-monitoring/feedback-api-token --secret-string '{"token":"..."}'
aws secretsmanager create-secret --name bedrock-monitoring/evaluation-api-token --secret-string '{"token":"..."}'

# 4. List your agents
#    Edit config/agents.yaml — one block per Bedrock agent (see section above)

# 5. Enable logging (see Prerequisites above) on each agent you listed

# 6. Env vars for the custom APIs (URLs only — tokens come from Secrets Manager)
export FEEDBACK_API_URL="https://your-feedback-api.example.com/items"
export EVALUATION_API_URL="https://your-evaluation-api.example.com/items"
export AWS_REGION="us-east-1"

# 7. Run the pipeline once to confirm everything's wired up
python -m collectors.scheduler

# 8. Deploy the pipeline on a schedule — either:
#    a) package collectors/scheduler.py as a Lambda, attach the IAM role from step 1,
#       and add one EventBridge rule per COLLECTOR_SCHEDULE entry passing {"source": "<name>"}
#    b) run it as a loop / cron on ECS with the same role attached

# 9. Start the API
uvicorn api.main:app --reload --port 8001

# 10. Wire the dashboard tab
#     Include dashboard/templates/bedrock_monitoring_tab.html in your Flask app and
#     point API_BASE (top of the file's <script>) at wherever step 9 is deployed.
```
