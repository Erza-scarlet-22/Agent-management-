from datetime import datetime
import boto3
from .base_collector import BaseCollector


class ExecutionsCollector(BaseCollector):
    """
    Populates the 'executions' table — one row per agent invocation *run*
    (session_id, correlation_id, start/end, status, duration), matching the
    executions table in your PostgreSQL schema. This is distinct from
    performance_metrics (per-metric readings) and model_invocations (per
    model call, which one execution can have several of if the agent makes
    multiple LLM calls or tool calls in a single turn).

    Sourced from X-Ray trace roots — a full agent trace maps 1:1 to an execution.
    """
    source_name = "executions"

    def __init__(self, region: str = "us-east-1"):
        super().__init__(region)
        self.client = boto3.client("xray", region_name=region)

    def collect(self, since: datetime) -> list[dict]:
        records = []
        paginator = self.client.get_paginator("get_trace_summaries")
        for page in paginator.paginate(
            StartTime=since,
            EndTime=self.now(),
            FilterExpression='service("bedrock-agent")',
        ):
            for trace in page.get("TraceSummaries", []):
                status = "FAILED" if (trace.get("HasError") or trace.get("HasFault")) else "SUCCESS"
                start = trace.get("StartTime")
                end = trace.get("StartTime")
                duration_ms = round(trace.get("Duration", 0) * 1000, 2)
                records.append({
                    "source": self.source_name,
                    "agent_id": _extract_agent_id(trace),
                    "execution_id": trace.get("Id"),
                    "session_id": _extract_annotation(trace, "session_id"),
                    "correlation_id": _extract_annotation(trace, "correlation_id") or trace.get("Id"),
                    "start_time": start.isoformat() if start else None,
                    "end_time": (start.isoformat() if start else None),  # X-Ray gives duration, not end ts
                    "duration_ms": duration_ms,
                    "status": status,
                    "timestamp": start.isoformat() if start else None,
                })
        return records


def _extract_agent_id(trace: dict) -> str:
    for ann in trace.get("Annotations", {}).get("agent_id", []):
        return ann.get("AnnotationValue", {}).get("StringValue", "unknown-agent")
    return "unknown-agent"


def _extract_annotation(trace: dict, key: str) -> str | None:
    for ann in trace.get("Annotations", {}).get(key, []):
        return ann.get("AnnotationValue", {}).get("StringValue")
    return None
