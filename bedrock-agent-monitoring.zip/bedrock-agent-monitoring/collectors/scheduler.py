"""
Orchestrator: runs each collector, hands raw records to the transformer, then
loads normalized records into DynamoDB. Deploy this as a Lambda on an
EventBridge schedule (one rule per COLLECTOR_SCHEDULE entry) or run as a loop
locally / in an ECS scheduled task.
"""
import logging
from datetime import datetime, timedelta, timezone

from config.settings import COLLECTOR_SCHEDULE, AWS_REGION
from collectors.cloudtrail_collector import CloudTrailCollector
from collectors.xray_collector import XRayCollector
from collectors.cloudwatch_alarms_collector import CloudWatchAlarmsCollector
from collectors.cost_explorer_collector import CostExplorerCollector
from collectors.lookout_metrics_collector import LookoutMetricsCollector
from collectors.feedback_api_collector import FeedbackAPICollector
from collectors.guardrails_collector import GuardrailsCollector
from collectors.bedrock_invocation_collector import BedrockInvocationCollector
from collectors.knowledge_base_collector import KnowledgeBaseCollector
from transformer.normalizer import normalize
from storage.dynamodb_loader import DynamoDBLoader

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

COLLECTORS = {
    "cloudtrail": CloudTrailCollector,
    "xray": XRayCollector,
    "cloudwatch_alarms": CloudWatchAlarmsCollector,
    "cost_explorer": CostExplorerCollector,
    "lookout_metrics": LookoutMetricsCollector,
    "feedback_api": FeedbackAPICollector,
    "guardrails": GuardrailsCollector,
    "bedrock_invocations": BedrockInvocationCollector,
    "knowledge_base": KnowledgeBaseCollector,
}


def run_pipeline(source: str | None = None):
    """Run one collector (source=name) or all of them (source=None)."""
    loader = DynamoDBLoader(region=AWS_REGION)
    names = [source] if source else list(COLLECTORS.keys())

    for name in names:
        interval_min = COLLECTOR_SCHEDULE.get(name, 5)
        since = datetime.now(timezone.utc) - timedelta(minutes=interval_min)
        collector = COLLECTORS[name](region=AWS_REGION)
        raw_records = collector.run(since)
        clean_records = [normalize(r) for r in raw_records]
        clean_records = [r for r in clean_records if r is not None]
        if clean_records:
            loader.load(name, clean_records)
        logger.info("[%s] loaded %d records", name, len(clean_records))


def lambda_handler(event, context):
    """EventBridge invokes with {"source": "<collector_name>"} per scheduled rule."""
    run_pipeline(event.get("source"))
    return {"status": "ok"}


if __name__ == "__main__":
    run_pipeline()
