from datetime import datetime, timedelta
import boto3
from .base_collector import BaseCollector


class CostExplorerCollector(BaseCollector):
    """Cost Explorer data lags ~24h — pair with the Bedrock model-invocation-logging
    based cost estimate in guardrails_collector.py for near-real-time numbers."""
    source_name = "cost_explorer"

    def __init__(self, region: str = "us-east-1"):
        super().__init__(region)
        self.client = boto3.client("ce", region_name="us-east-1")  # CE is us-east-1 only

    def collect(self, since: datetime) -> list[dict]:
        start = since.date().isoformat()
        end = (self.now() + timedelta(days=1)).date().isoformat()
        response = self.client.get_cost_and_usage(
            TimePeriod={"Start": start, "End": end},
            Granularity="DAILY",
            Metrics=["UnblendedCost"],
            Filter={"Dimensions": {"Key": "SERVICE", "Values": ["Amazon Bedrock"]}},
            GroupBy=[{"Type": "TAG", "Key": "agent_id"}],
        )
        records = []
        for result in response.get("ResultsByTime", []):
            date = result["TimePeriod"]["Start"]
            for group in result.get("Groups", []):
                agent_id = group["Keys"][0].split("$")[-1] or "unattributed"
                records.append({
                    "source": self.source_name,
                    "agent_id": agent_id,
                    "date": date,
                    "service": "bedrock",
                    "cost_usd": float(group["Metrics"]["UnblendedCost"]["Amount"]),
                })
        return records
