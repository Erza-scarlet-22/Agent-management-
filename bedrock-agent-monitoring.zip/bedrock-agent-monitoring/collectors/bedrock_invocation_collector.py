from datetime import datetime
import json
import boto3
from .base_collector import BaseCollector
from config.settings import SLOW_RESPONSE_THRESHOLD_MS


class BedrockInvocationCollector(BaseCollector):
    """
    Reads EVERY entry in the Bedrock model-invocation-logging CloudWatch Logs
    group (not just guardrail interventions, which guardrails_collector.py
    already covers). This is the "give me every other log" source: tokens,
    latency, model, stop reason, per call.

    Requires model invocation logging enabled on the account:
    Bedrock console -> Settings -> Model invocation logging -> CloudWatch Logs.
    """
    source_name = "bedrock_invocations"

    def __init__(self, region: str = "us-east-1", log_group: str = "/aws/bedrock/modelinvocations"):
        super().__init__(region)
        self.client = boto3.client("logs", region_name=region)
        self.log_group = log_group

    def collect(self, since: datetime) -> list[dict]:
        records = []
        try:
            paginator = self.client.get_paginator("filter_log_events")
            for page in paginator.paginate(
                logGroupName=self.log_group,
                startTime=int(since.timestamp() * 1000),
            ):
                for event in page.get("events", []):
                    parsed = _parse_invocation(event)
                    if parsed:
                        records.append(parsed)
        except self.client.exceptions.ResourceNotFoundException:
            pass
        return records


def _parse_invocation(event: dict) -> dict | None:
    try:
        body = json.loads(event["message"])
    except (json.JSONDecodeError, KeyError):
        return None

    input_tokens = body.get("input", {}).get("inputTokenCount", 0)
    output_tokens = body.get("output", {}).get("outputTokenCount", 0)
    latency_ms = body.get("output", {}).get("latencyMs") or body.get("latencyMs", 0)
    agent_id = body.get("customizationSource") or body.get("identity", {}).get("arn", "unknown-agent")

    return {
        "source": "bedrock_invocations",
        "agent_id": _shorten_arn(agent_id),
        "model_id": body.get("modelId", "unknown-model"),
        "invocation_id": event.get("eventId"),
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": input_tokens + output_tokens,
        "latency_ms": latency_ms,
        "is_slow": bool(latency_ms and latency_ms > SLOW_RESPONSE_THRESHOLD_MS),
        "stop_reason": body.get("output", {}).get("outputBodyJson", {}).get("stop_reason", "unknown"),
        "guardrail_action": body.get("output", {}).get("outputBodyJson", {})
                                 .get("amazon-bedrock-guardrailAction", "NONE"),
        "timestamp": datetime.utcfromtimestamp(event["timestamp"] / 1000).isoformat(),
    }


def _shorten_arn(arn: str) -> str:
    return arn.split("/")[-1] if "/" in arn else arn
