from datetime import datetime
import boto3
from .base_collector import BaseCollector


class XRayCollector(BaseCollector):
    """Pulls trace summaries for Bedrock agent invocations (latency, error/fault flags)."""
    source_name = "xray"

    def __init__(self, region: str = "us-east-1"):
        super().__init__(region)
        self.client = boto3.client("xray", region_name=region)

    def collect(self, since: datetime) -> list[dict]:
        records = []
        paginator = self.client.get_paginator("get_trace_summaries")
        for page in paginator.paginate(
            StartTime=since,
            EndTime=self.now(),
            FilterExpression='service("bedrock-agent")',
        ):
            for trace in page.get("TraceSummaries", []):
                records.append({
                    "source": self.source_name,
                    "agent_id": _extract_agent_id(trace),
                    "trace_id": trace.get("Id"),
                    "duration_ms": round(trace.get("Duration", 0) * 1000, 2),
                    "response_time_ms": round(trace.get("ResponseTime", 0) * 1000, 2),
                    "has_error": trace.get("HasError", False),
                    "has_fault": trace.get("HasFault", False),
                    "has_throttle": trace.get("HasThrottle", False),
                    "timestamp": trace.get("StartTime").isoformat() if trace.get("StartTime") else None,
                })
        return records


def _extract_agent_id(trace: dict) -> str:
    for ann in trace.get("Annotations", {}).get("agent_id", []):
        return ann.get("AnnotationValue", {}).get("StringValue", "unknown-agent")
    return "unknown-agent"
