from datetime import datetime
import json
import boto3
from .base_collector import BaseCollector

NO_ANSWER_PHRASES = (
    "i don't have enough information",
    "i do not have enough information",
    "i'm not able to find",
    "i am not able to find",
    "no relevant information",
    "i don't know",
    "cannot answer that",
)


class KnowledgeBaseCollector(BaseCollector):
    """
    Reads Bedrock Agent trace logs (enable "Trace" on the agent alias, and point
    trace logging at a CloudWatch Logs group) and pulls out every
    knowledgeBaseLookupOutput step. Flags a query as a "no-answer" event when
    either:
      - the retrieval returned zero references (KB has no relevant chunk), or
      - the final generated response matches a known "I don't know" pattern

    This is the piece your original architecture didn't have: PostgreSQL/Failures
    only caught exceptions, not "the agent technically responded but didn't
    actually answer."
    """
    source_name = "knowledge_base"

    def __init__(self, region: str = "us-east-1", log_group: str = "/aws/bedrock/agenttraces"):
        super().__init__(region)
        self.client = boto3.client("logs", region_name=region)
        self.log_group = log_group

    def collect(self, since: datetime) -> list[dict]:
        records = []
        try:
            paginator = self.client.get_paginator("filter_log_events")
            for page in paginator.paginate(
                logGroupName=self.log_group,
                startTime=int(since.timestamp() * 1000),
                filterPattern='{ $.trace.orchestrationTrace.observation.knowledgeBaseLookupOutput = "*" }',
            ):
                for event in page.get("events", []):
                    parsed = _parse_kb_trace(event)
                    if parsed:
                        records.append(parsed)
        except self.client.exceptions.ResourceNotFoundException:
            pass
        return records


def _parse_kb_trace(event: dict) -> dict | None:
    try:
        body = json.loads(event["message"])
    except (json.JSONDecodeError, KeyError):
        return None

    trace = body.get("trace", {}).get("orchestrationTrace", {})
    kb_output = trace.get("observation", {}).get("knowledgeBaseLookupOutput", {})
    references = kb_output.get("retrievedReferences", [])
    final_response = body.get("trace", {}).get("orchestrationTrace", {}) \
                          .get("observation", {}).get("finalResponse", {}).get("text", "")

    no_answer = len(references) == 0 or any(p in final_response.lower() for p in NO_ANSWER_PHRASES)

    return {
        "source": "knowledge_base",
        "agent_id": body.get("agentId", "unknown-agent"),
        "session_id": body.get("sessionId", "unknown-session"),
        "kb_id": kb_output.get("knowledgeBaseId", "unknown-kb"),
        "query": kb_output.get("query", {}).get("text", ""),
        "citation_count": len(references),
        "top_score": max((r.get("score", 0) for r in references), default=0),
        "no_answer": no_answer,
        "response_excerpt": final_response[:200],
        "timestamp": datetime.utcfromtimestamp(event["timestamp"] / 1000).isoformat(),
    }
