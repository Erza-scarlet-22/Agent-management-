from datetime import datetime
import os
import requests
from .base_collector import BaseCollector
from config.agent_registry import get_custom_api_config
from storage.secrets_manager import get_secret


class EvaluationAPICollector(BaseCollector):
    """
    Your custom Evaluation API (the other custom-API box from the original
    diagram — Feedback API was already wired up, this one wasn't). Populates
    'accuracy_evaluations': accuracy/relevance/completeness scores per execution.
    """
    source_name = "evaluation_api"

    def collect(self, since: datetime) -> list[dict]:
        cfg = get_custom_api_config("evaluation_api")
        url = os.getenv(cfg.get("url_env_var", ""), "")
        if not url:
            return []

        token = get_secret(cfg.get("secret_name", ""), region=self.region)
        headers = {"Authorization": f"Bearer {token}"} if token else {}

        resp = requests.get(url, params={"since": since.isoformat()}, headers=headers, timeout=10)
        resp.raise_for_status()

        return [
            {
                "source": self.source_name,
                "agent_id": item.get("agent_id", "unknown-agent"),
                "execution_id": item.get("execution_id"),
                "evaluation_id": item.get("evaluation_id"),
                "accuracy_score": item.get("accuracy_score"),
                "relevance_score": item.get("relevance_score"),
                "completeness_score": item.get("completeness_score"),
                "evaluation_result": item.get("evaluation_result", "unknown"),
                "timestamp": item.get("evaluated_at"),
            }
            for item in resp.json().get("items", [])
        ]
