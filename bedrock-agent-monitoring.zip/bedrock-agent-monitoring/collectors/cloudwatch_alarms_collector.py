from datetime import datetime
import boto3
from .base_collector import BaseCollector


class CloudWatchAlarmsCollector(BaseCollector):
    source_name = "cloudwatch_alarms"

    def __init__(self, region: str = "us-east-1"):
        super().__init__(region)
        self.client = boto3.client("cloudwatch", region_name=region)

    def collect(self, since: datetime) -> list[dict]:
        records = []
        paginator = self.client.get_paginator("describe_alarms")
        for page in paginator.paginate(AlarmNamePrefix="bedrock-agent-"):
            for alarm in page.get("MetricAlarms", []):
                if alarm.get("StateUpdatedTimestamp", since) < since:
                    continue
                records.append({
                    "source": self.source_name,
                    "agent_id": alarm.get("AlarmName", "").replace("bedrock-agent-", "").split("-")[0],
                    "alarm_name": alarm.get("AlarmName"),
                    "state": alarm.get("StateValue"),
                    "reason": alarm.get("StateReason"),
                    "metric_name": alarm.get("MetricName"),
                    "timestamp": alarm.get("StateUpdatedTimestamp").isoformat(),
                })
        return records
