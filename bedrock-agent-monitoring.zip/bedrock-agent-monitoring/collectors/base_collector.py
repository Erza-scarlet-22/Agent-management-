"""
Shared contract every collector implements. Each collector is responsible only
for pulling raw data from one AWS/custom source and yielding normalized-ish
dicts; the transformer layer does the real schema validation.
"""
from abc import ABC, abstractmethod
from datetime import datetime, timezone
import logging

logger = logging.getLogger(__name__)


class BaseCollector(ABC):
    source_name: str = "base"

    def __init__(self, region: str = "us-east-1"):
        self.region = region

    @abstractmethod
    def collect(self, since: datetime) -> list[dict]:
        """Return raw records observed since `since` (UTC)."""
        raise NotImplementedError

    def run(self, since: datetime) -> list[dict]:
        try:
            records = self.collect(since)
            logger.info("[%s] collected %d records", self.source_name, len(records))
            return records
        except Exception:
            logger.exception("[%s] collection failed", self.source_name)
            return []

    @staticmethod
    def now() -> datetime:
        return datetime.now(timezone.utc)
