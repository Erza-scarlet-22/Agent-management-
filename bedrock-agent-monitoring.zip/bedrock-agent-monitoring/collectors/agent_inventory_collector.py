from datetime import datetime
import boto3
from .base_collector import BaseCollector
from config.agent_registry import get_agents


class AgentInventoryCollector(BaseCollector):
    """
    Populates AgentInventory: one row per agent from config/agents.yaml, enriched
    with live status pulled from Bedrock's control-plane API (get_agent). This is
    what makes "agent_inventory.status" and "updated_at" actually reflect reality
    instead of only what's hand-typed in the YAML.

    Unlike the other collectors this isn't time-windowed — it re-syncs the full
    registry every run, since inventory is small and state (not new events) is
    what matters.
    """
    source_name = "agent_inventory"

    def __init__(self, region: str = "us-east-1"):
        super().__init__(region)
        self.client = boto3.client("bedrock-agent", region_name=region)

    def collect(self, since: datetime) -> list[dict]:
        records = []
        for agent_cfg in get_agents():
            live_status = self._fetch_live_status(agent_cfg["agent_id"])
            records.append({
                "source": self.source_name,
                "agent_id": agent_cfg["agent_id"],
                "agent_name": agent_cfg.get("agent_name", "unknown"),
                "agent_alias_id": agent_cfg.get("agent_alias_id"),
                "foundation_model": agent_cfg.get("foundation_model", "unknown"),
                "environment": agent_cfg.get("environment", "unknown"),
                "knowledge_base_id": agent_cfg.get("knowledge_base_id") or None,
                "status": live_status,
                "updated_at": self.now().isoformat(),
            })
        return records

    def _fetch_live_status(self, agent_id: str) -> str:
        try:
            resp = self.client.get_agent(agentId=agent_id)
            return resp.get("agent", {}).get("agentStatus", "UNKNOWN")
        except Exception:
            return "UNREACHABLE"
