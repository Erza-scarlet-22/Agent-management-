from datetime import datetime
import boto3
from .base_collector import BaseCollector

BEDROCK_EVENT_NAMES = {
    "InvokeAgent", "InvokeModel", "CreateAgent", "UpdateAgent",
    "DeleteAgent", "InvokeAgentRuntime",
}


class CloudTrailCollector(BaseCollector):
    source_name = "cloudtrail"

    def __init__(self, region: str = "us-east-1"):
        super().__init__(region)
        self.client = boto3.client("cloudtrail", region_name=region)

    def collect(self, since: datetime) -> list[dict]:
        records = []
        paginator = self.client.get_paginator("lookup_events")
        for page in paginator.paginate(
            StartTime=since,
            EndTime=self.now(),
            LookupAttributes=[{"AttributeKey": "EventSource", "AttributeValue": "bedrock.amazonaws.com"}],
        ):
            for event in page.get("Events", []):
                if event.get("EventName") not in BEDROCK_EVENT_NAMES:
                    continue
                records.append({
                    "source": self.source_name,
                    "agent_id": _extract_agent_id(event),
                    "event_name": event.get("EventName"),
                    "event_time": event.get("EventTime").isoformat(),
                    "username": event.get("Username", "unknown"),
                    "event_id": event.get("EventId"),
                    "raw": event.get("CloudTrailEvent"),
                })
        return records


def _extract_agent_id(event: dict) -> str:
    for r in event.get("Resources", []):
        if r.get("ResourceType", "").startswith("AWS::Bedrock"):
            return r.get("ResourceName", "unknown-agent")
    return "unknown-agent"
