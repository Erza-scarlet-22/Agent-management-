from datetime import datetime
import os
import requests
from .base_collector import BaseCollector
from config.agent_registry import get_custom_api_config
from storage.secrets_manager import get_secret


class FeedbackAPICollector(BaseCollector):
    """Pulls your custom Feedback API (rightmost box in AWS Data Sources)."""
    source_name = "feedback_api"

    def collect(self, since: datetime) -> list[dict]:
        cfg = get_custom_api_config("feedback_api")
        url = os.getenv(cfg.get("url_env_var", ""), "")
        if not url:
            return []

        token = get_secret(cfg.get("secret_name", ""), region=self.region)
        headers = {"Authorization": f"Bearer {token}"} if token else {}

        resp = requests.get(url, params={"since": since.isoformat()}, headers=headers, timeout=10)
        resp.raise_for_status()

        return [
            {
                "source": self.source_name,
                "agent_id": item.get("agent_id", "unknown-agent"),
                "execution_id": item.get("execution_id"),
                "feedback_id": item.get("feedback_id"),
                "rating": item.get("rating"),
                "is_thumbs_up": item.get("rating", 0) >= 4 if item.get("rating") is not None
                                 else item.get("is_thumbs_up"),
                "comments": item.get("comment") or item.get("comments"),
                "timestamp": item.get("timestamp") or item.get("created_at"),
            }
            for item in resp.json().get("items", [])
        ]
