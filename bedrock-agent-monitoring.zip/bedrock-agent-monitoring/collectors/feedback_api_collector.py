from datetime import datetime
import requests
from .base_collector import BaseCollector
from config.settings import FEEDBACK_API_URL


class FeedbackAPICollector(BaseCollector):
    """Pulls your custom Feedback/Evaluation API (rightmost box in AWS Data Sources)."""
    source_name = "feedback_api"

    def collect(self, since: datetime) -> list[dict]:
        if not FEEDBACK_API_URL:
            return []
        resp = requests.get(
            FEEDBACK_API_URL,
            params={"since": since.isoformat()},
            timeout=10,
        )
        resp.raise_for_status()
        return [
            {
                "source": self.source_name,
                "agent_id": item.get("agent_id", "unknown-agent"),
                "rating": item.get("rating"),
                "comment": item.get("comment"),
                "timestamp": item.get("timestamp"),
                "user_id": item.get("user_id", "anonymous"),
            }
            for item in resp.json().get("items", [])
        ]
