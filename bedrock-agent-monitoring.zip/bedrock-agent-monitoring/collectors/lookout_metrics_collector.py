from datetime import datetime
import boto3
from .base_collector import BaseCollector


class LookoutMetricsCollector(BaseCollector):
    source_name = "lookout_metrics"

    def __init__(self, region: str = "us-east-1", anomaly_detector_arn: str = ""):
        super().__init__(region)
        self.client = boto3.client("lookoutmetrics", region_name=region)
        self.detector_arn = anomaly_detector_arn

    def collect(self, since: datetime) -> list[dict]:
        if not self.detector_arn:
            return []
        records = []
        paginator = self.client.get_paginator("list_anomaly_group_summaries")
        for page in paginator.paginate(
            AnomalyDetectorArn=self.detector_arn,
            SensitivityThreshold=50,
        ):
            for group in page.get("AnomalyGroupSummaryList", []):
                start = group.get("StartTime")
                if start and datetime.fromisoformat(start) < since:
                    continue
                records.append({
                    "source": self.source_name,
                    "agent_id": group.get("AnomalyGroupId", "unknown-agent"),
                    "anomaly_group_id": group.get("AnomalyGroupId"),
                    "score": group.get("AnomalyGroupScore"),
                    "start_time": start,
                })
        return records
