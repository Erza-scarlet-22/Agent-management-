from datetime import datetime
import boto3
from .base_collector import BaseCollector


class GuardrailsCollector(BaseCollector):
    """
    Extra source (not in the original diagram): pulls Bedrock Guardrails
    intervention logs from the CloudWatch Logs group Bedrock writes model-invocation
    logs to. Surfaces blocked/flagged content, PII redactions, and denied topics —
    a failure mode your current Failures table won't otherwise catch, since a
    guardrail block isn't an exception or a CloudWatch alarm, it's a silent redirect.
    """
    source_name = "guardrails"

    def __init__(self, region: str = "us-east-1", log_group: str = "/aws/bedrock/modelinvocations"):
        super().__init__(region)
        self.client = boto3.client("logs", region_name=region)
        self.log_group = log_group

    def collect(self, since: datetime) -> list[dict]:
        records = []
        try:
            paginator = self.client.get_paginator("filter_log_events")
            for page in paginator.paginate(
                logGroupName=self.log_group,
                startTime=int(since.timestamp() * 1000),
                filterPattern='{ $.output.outputBodyJson.amazon-bedrock-guardrailAction = "INTERVENED" }',
            ):
                for event in page.get("events", []):
                    records.append({
                        "source": self.source_name,
                        "agent_id": _extract_agent_id(event.get("logStreamName", "")),
                        "event_id": event.get("eventId"),
                        "timestamp": datetime.utcfromtimestamp(event["timestamp"] / 1000).isoformat(),
                        "message": event.get("message"),
                    })
        except self.client.exceptions.ResourceNotFoundException:
            pass  # log group not enabled yet — non-fatal
        return records


def _extract_agent_id(log_stream_name: str) -> str:
    return log_stream_name.split("/")[0] if "/" in log_stream_name else "unknown-agent"
