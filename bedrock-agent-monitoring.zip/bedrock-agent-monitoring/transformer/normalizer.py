"""
Normalizes raw collector output into the shape storage/dynamodb_loader.py expects:
every record needs agent_id + a UTC ISO timestamp field, so the loader can build
composite sort keys consistently across sources.
"""
from datetime import datetime, timezone
import uuid
import logging

from config.settings import SLOW_RESPONSE_THRESHOLD_MS

logger = logging.getLogger(__name__)

TIMESTAMP_FIELD_BY_SOURCE = {
    "cloudtrail": "event_time",
    "xray": "timestamp",
    "cloudwatch_alarms": "timestamp",
    "cost_explorer": "date",
    "lookout_metrics": "start_time",
    "feedback_api": "timestamp",
    "guardrails": "timestamp",
    "bedrock_invocations": "timestamp",
    "knowledge_base": "timestamp",
    "executions": "timestamp",
    "evaluation_api": "timestamp",
    "agent_inventory": "updated_at",
}

# Any of these present + over threshold => flag is_slow, regardless of source.
LATENCY_FIELDS = ("duration_ms", "response_time_ms", "latency_ms")

REQUIRED_FIELDS = {"source", "agent_id"}


def normalize(record: dict) -> dict | None:
    if not REQUIRED_FIELDS.issubset(record):
        logger.warning("dropping record missing required fields: %s", record)
        return None

    source = record["source"]
    ts_field = TIMESTAMP_FIELD_BY_SOURCE.get(source)
    ts_value = record.get(ts_field) if ts_field else None

    record["timestamp"] = _to_iso_utc(ts_value)
    record["agent_id"] = record["agent_id"] or "unattributed"
    record.setdefault("record_id", str(uuid.uuid4()))
    _flag_slow_response(record)
    return record


def _flag_slow_response(record: dict) -> None:
    """Sets is_slow=True on any record whose latency exceeds the threshold,
    so slow responses are queryable the same way across every source
    (X-Ray traces, raw model invocations, KB retrieval) instead of only
    living inside whichever table happened to collect them."""
    for field in LATENCY_FIELDS:
        value = record.get(field)
        if value is not None:
            record["is_slow"] = bool(value > SLOW_RESPONSE_THRESHOLD_MS)
            return
    record.setdefault("is_slow", False)


def _to_iso_utc(value) -> str:
    if value is None:
        return datetime.now(timezone.utc).isoformat()
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc).isoformat()
    # already a string (ISO or plain date) — pass through
    return str(value)
