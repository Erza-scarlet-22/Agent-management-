"""
Tests a real collector against a MOCKED AWS API (via moto) — no real AWS
account, no credentials, no network. This is the template for testing any
other collector: swap the moto decorator's service, seed fake data with the
same boto3 client the collector uses, then call collector.collect().

Requires: pip install moto --break-system-packages
"""
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, ".")

import boto3
from moto import mock_aws

from collectors.cloudwatch_alarms_collector import CloudWatchAlarmsCollector


@mock_aws
def test_cloudwatch_alarms_collector_returns_recent_alarm():
    region = "us-east-1"
    client = boto3.client("cloudwatch", region_name=region)

    client.put_metric_alarm(
        AlarmName="bedrock-agent-AGENT123ABC-errors",
        MetricName="Errors",
        Namespace="AWS/Bedrock",
        Statistic="Sum",
        Period=60,
        EvaluationPeriods=1,
        Threshold=1,
        ComparisonOperator="GreaterThanThreshold",
        ActionsEnabled=False,
    )

    collector = CloudWatchAlarmsCollector(region=region)
    since = datetime.now(timezone.utc) - timedelta(hours=1)
    records = collector.collect(since)

    assert len(records) == 1
    assert records[0]["agent_id"] == "AGENT123ABC"
    assert records[0]["alarm_name"] == "bedrock-agent-AGENT123ABC-errors"


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
