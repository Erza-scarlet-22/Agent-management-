"""
Pure logic tests — no AWS, no Docker, just `pytest`. Run these first;
if these fail, nothing downstream will work either.
"""
import sys
sys.path.insert(0, ".")

from transformer.normalizer import normalize, _flag_slow_response


def test_normalize_drops_records_missing_required_fields():
    assert normalize({"source": "xray"}) is None          # missing agent_id
    assert normalize({"agent_id": "a1"}) is None           # missing source


def test_normalize_sets_timestamp_and_record_id():
    result = normalize({"source": "xray", "agent_id": "a1", "timestamp": "2026-01-01T00:00:00+00:00"})
    assert result["timestamp"] == "2026-01-01T00:00:00+00:00"
    assert "record_id" in result


def test_normalize_defaults_missing_timestamp_to_now():
    result = normalize({"source": "cloudwatch_alarms", "agent_id": "a1"})
    assert result["timestamp"] is not None


def test_slow_response_flagged_above_threshold():
    record = {"duration_ms": 5000}
    _flag_slow_response(record)
    assert record["is_slow"] is True


def test_slow_response_not_flagged_below_threshold():
    record = {"duration_ms": 500}
    _flag_slow_response(record)
    assert record["is_slow"] is False


def test_slow_response_defaults_false_when_no_latency_field():
    record = {}
    _flag_slow_response(record)
    assert record["is_slow"] is False


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
